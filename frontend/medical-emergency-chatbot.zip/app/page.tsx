'use client'

import { useEffect, useState } from 'react'
import { useAccessibilityState } from '@/hooks/useAccessibilityState'
import { StatusBar } from '@/components/StatusBar'
import { SafetyBanner } from '@/components/SafetyBanner'
import { VisualGuide } from '@/components/VisualGuide'
import { ChatWindow } from '@/components/ChatWindow'
import { ActionBar } from '@/components/ActionBar'
import { AccessibilityPanel } from '@/components/AccessibilityPanel'

interface ChatMessage {
  id: string
  type: 'bot' | 'user'
  text: string
  timestamp: Date
}

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [showSettings, setShowSettings] = useState(false)
  const [isOffline] = useState(true)
  const accessibility = useAccessibilityState()

  // Simulate a bot response
  const handleAddBotMessage = (text: string) => {
    const newMessage: ChatMessage = {
      id: `bot-${Date.now()}`,
      type: 'bot',
      text,
      timestamp: new Date(),
    }
    setMessages(prev => [...prev, newMessage])
  }

  // Simulate a user message
  const handleAddUserMessage = (text: string) => {
    const newMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      type: 'user',
      text,
      timestamp: new Date(),
    }
    setMessages(prev => [...prev, newMessage])

    // Simulate bot response after 1 second
    setTimeout(() => {
      handleAddBotMessage(
        'Thank you for sharing that. Based on your symptoms, I recommend: 1) Rest in a comfortable position 2) Stay hydrated 3) Monitor your condition. If symptoms worsen, contact emergency services immediately.'
      )
    }, 1000)
  }

  const handleMicPress = () => {
    accessibility.setIsListening(true)
    // Simulate voice input
    setTimeout(() => {
      accessibility.setIsListening(false)
      handleAddUserMessage('I have a headache and mild fever')
    }, 2000)
  }

  const handleMicRelease = () => {
    accessibility.setIsListening(false)
  }

  const handlePlayAudio = () => {
    if (messages.length === 0) return
    accessibility.setIsPlayingVoice(true)
    setTimeout(() => {
      accessibility.setIsPlayingVoice(false)
    }, 2000)
  }

  const handleReset = () => {
    setMessages([])
    accessibility.setIsListening(false)
    accessibility.setIsPlayingVoice(false)
  }

  const handleSettings = () => {
    setShowSettings(true)
  }

  return (
    <main className="h-screen bg-slate-900 flex flex-col max-w-md mx-auto w-full overflow-hidden">
      {/* Status Bar */}
      <StatusBar isOffline={isOffline} />

      {/* Safety Banner - dismiss-able */}
      {accessibility.disclaimerVisible && (
        <SafetyBanner
          isVisible={accessibility.disclaimerVisible}
          onDismiss={() => accessibility.setDisclaimerVisible(false)}
          textScale={accessibility.textScale}
        />
      )}

      {/* Visual Guide */}
      <VisualGuide textScale={accessibility.textScale} />

      {/* Chat Window - main content area */}
      <ChatWindow
        messages={messages}
        isPlayingVoice={accessibility.isPlayingVoice}
        textScale={accessibility.textScale}
      />

      {/* Action Bar - controls */}
      <ActionBar
        isListening={accessibility.isListening}
        onMicPress={handleMicPress}
        onMicRelease={handleMicRelease}
        onPlayAudio={handlePlayAudio}
        onReset={handleReset}
        onSettings={handleSettings}
      />

      {/* Accessibility Settings Panel */}
      <AccessibilityPanel
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        textScale={accessibility.textScale}
        setTextScale={accessibility.setTextScale}
        isSlowSpeed={accessibility.isSlowSpeed}
        setIsSlowSpeed={accessibility.setIsSlowSpeed}
        isHighContrast={accessibility.isHighContrast}
        setIsHighContrast={accessibility.setIsHighContrast}
      />
    </main>
  )
}
