'use client'

import { X } from 'lucide-react'
import type { TextScale } from '@/hooks/useAccessibilityState'

interface AccessibilityPanelProps {
  isOpen: boolean
  onClose: () => void
  textScale: TextScale
  setTextScale: (scale: TextScale) => void
  isSlowSpeed: boolean
  setIsSlowSpeed: (value: boolean) => void
  isHighContrast: boolean
  setIsHighContrast: (value: boolean) => void
}

export function AccessibilityPanel({
  isOpen,
  onClose,
  textScale,
  setTextScale,
  isSlowSpeed,
  setIsSlowSpeed,
  isHighContrast,
  setIsHighContrast,
}: AccessibilityPanelProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-end">
      <div className="w-full bg-slate-800 border-t-4 border-emerald-500 rounded-t-lg p-4 max-w-md mx-auto max-h-96 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">Accessibility Options</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
            aria-label="Close settings"
          >
            <X size={20} className="text-white" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Text Size */}
          <div className="bg-slate-700 p-3 rounded-lg">
            <label className="block text-white font-bold mb-2">Text Size</label>
            <div className="flex gap-2">
              {(['normal', 'large', 'extra'] as const).map((scale) => (
                <button
                  key={scale}
                  onClick={() => setTextScale(scale)}
                  className={`flex-1 py-2 px-3 rounded font-bold transition-colors ${
                    textScale === scale
                      ? 'bg-emerald-500 text-slate-900'
                      : 'bg-slate-600 text-white hover:bg-slate-500'
                  }`}
                  aria-pressed={textScale === scale}
                >
                  {scale.charAt(0).toUpperCase() + scale.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Slow Speed */}
          <div className="bg-slate-700 p-3 rounded-lg">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isSlowSpeed}
                onChange={(e) => setIsSlowSpeed(e.target.checked)}
                className="w-5 h-5 cursor-pointer"
              />
              <span className="text-white font-bold">Slow Speech Speed</span>
            </label>
          </div>

          {/* High Contrast */}
          <div className="bg-slate-700 p-3 rounded-lg">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isHighContrast}
                onChange={(e) => setIsHighContrast(e.target.checked)}
                className="w-5 h-5 cursor-pointer"
              />
              <span className="text-white font-bold">High Contrast Mode</span>
            </label>
          </div>

          {/* Help Text */}
          <div className="bg-slate-700 p-3 rounded-lg text-sm text-gray-300">
            <p className="mb-2">
              <strong>Text Size:</strong> Adjust text for readability
            </p>
            <p className="mb-2">
              <strong>Slow Speech:</strong> Slow down voice output
            </p>
            <p>
              <strong>High Contrast:</strong> Enhance color contrast for visibility
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
