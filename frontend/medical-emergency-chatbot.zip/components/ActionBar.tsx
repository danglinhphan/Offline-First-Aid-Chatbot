'use client'

import { Volume2, RotateCcw, Settings } from 'lucide-react'
import { MicrophoneButton } from './MicrophoneButton'

interface ActionBarProps {
  isListening: boolean
  onMicPress: () => void
  onMicRelease: () => void
  onPlayAudio: () => void
  onReset: () => void
  onSettings: () => void
}

export function ActionBar({
  isListening,
  onMicPress,
  onMicRelease,
  onPlayAudio,
  onReset,
  onSettings,
}: ActionBarProps) {
  return (
    <div className="bg-slate-800 border-t-4 border-slate-700 px-4 py-4 flex flex-col gap-4">
      {/* Main microphone button */}
      <div className="flex justify-center">
        <MicrophoneButton
          isListening={isListening}
          onPress={onMicPress}
          onRelease={onMicRelease}
        />
      </div>

      {/* Secondary controls */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={onPlayAudio}
          className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-4 rounded-lg transition-colors border-2 border-slate-600 flex items-center justify-center gap-2 min-h-20"
          aria-label="Replay last message"
        >
          <Volume2 size={20} />
          <span className="text-sm">Replay</span>
        </button>

        <button
          onClick={onReset}
          className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-4 rounded-lg transition-colors border-2 border-slate-600 flex items-center justify-center gap-2 min-h-20"
          aria-label="Clear conversation"
        >
          <RotateCcw size={20} />
          <span className="text-sm">Clear</span>
        </button>

        <button
          onClick={onSettings}
          className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-4 rounded-lg transition-colors border-2 border-slate-600 flex items-center justify-center gap-2 min-h-20"
          aria-label="Accessibility settings"
        >
          <Settings size={20} />
          <span className="text-sm">Options</span>
        </button>
      </div>

      {/* Info text */}
      <div className="text-center text-xs text-gray-400">
        Press microphone button and speak clearly
      </div>
    </div>
  )
}
