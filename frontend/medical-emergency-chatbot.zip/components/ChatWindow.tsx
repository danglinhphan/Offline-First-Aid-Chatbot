'use client'

interface ChatMessage {
  id: string
  type: 'bot' | 'user'
  text: string
  timestamp: Date
}

interface ChatWindowProps {
  messages: ChatMessage[]
  isPlayingVoice: boolean
  textScale: 'normal' | 'large' | 'extra'
}

const textSizeMap = {
  normal: 'text-base',
  large: 'text-lg',
  extra: 'text-xl',
}

export function ChatWindow({ messages, isPlayingVoice, textScale }: ChatWindowProps) {
  return (
    <div className="flex-1 bg-slate-900 overflow-y-auto p-4 space-y-3 min-h-0">
      {messages.length === 0 ? (
        <div className="h-full flex items-center justify-center text-center">
          <div>
            <div className={`${textSizeMap[textScale]} font-bold text-white mb-2`}>
              👋 Welcome to Medical Assistant
            </div>
            <div className={`${textSizeMap[textScale]} text-gray-400`}>
              Describe your symptoms or ask for medical guidance.
            </div>
          </div>
        </div>
      ) : (
        messages.map((msg) => (
          <div 
            key={msg.id}
            className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs px-4 py-3 rounded-lg ${
                msg.type === 'user'
                  ? 'bg-emerald-600 text-white'
                  : isPlayingVoice && msg === messages[messages.length - 1]
                  ? 'bg-slate-700 text-white border-2 border-emerald-400'
                  : 'bg-slate-700 text-white'
              }`}
              role={msg.type === 'bot' ? 'status' : undefined}
              aria-label={msg.type === 'user' ? 'Your message' : 'Assistant response'}
            >
              <div className={`${textSizeMap[textScale]} leading-relaxed`}>
                {msg.text}
              </div>
              <div className="text-xs text-gray-300 mt-2 opacity-70">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  )
}
