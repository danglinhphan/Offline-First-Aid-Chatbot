'use client'

import { Mic, MicOff } from 'lucide-react'
import { useEffect, useRef } from 'react'

interface MicrophoneButtonProps {
  isListening: boolean
  onPress: () => void
  onRelease: () => void
}

export function MicrophoneButton({ isListening, onPress, onRelease }: MicrophoneButtonProps) {
  const buttonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    const handleMouseDown = () => onPress()
    const handleMouseUp = () => onRelease()
    const handleTouchStart = () => onPress()
    const handleTouchEnd = () => onRelease()

    const btn = buttonRef.current
    if (!btn) return

    btn.addEventListener('mousedown', handleMouseDown)
    btn.addEventListener('mouseup', handleMouseUp)
    btn.addEventListener('touchstart', handleTouchStart)
    btn.addEventListener('touchend', handleTouchEnd)

    return () => {
      btn.removeEventListener('mousedown', handleMouseDown)
      btn.removeEventListener('mouseup', handleMouseUp)
      btn.removeEventListener('touchstart', handleTouchStart)
      btn.removeEventListener('touchend', handleTouchEnd)
    }
  }, [onPress, onRelease])

  return (
    <div className="relative">
      {/* Ripple animation */}
      {isListening && (
        <>
          <div className="absolute inset-0 bg-emerald-400 rounded-full animate-pulse opacity-50" />
          <div className="absolute inset-0 bg-emerald-400 rounded-full animate-ping opacity-75" />
        </>
      )}
      
      <button
        ref={buttonRef}
        className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-200 font-bold text-white text-sm border-4 ${
          isListening
            ? 'bg-emerald-500 border-emerald-400 shadow-lg shadow-emerald-500/50'
            : 'bg-slate-700 border-slate-600 hover:bg-slate-600'
        }`}
        aria-label={isListening ? 'Stop listening' : 'Press to speak'}
        aria-pressed={isListening}
      >
        {isListening ? (
          <Mic size={32} className="text-white" />
        ) : (
          <MicOff size={32} className="text-gray-400" />
        )}
      </button>
    </div>
  )
}
