'use client'

import { AlertTriangle, X } from 'lucide-react'

interface SafetyBannerProps {
  isVisible: boolean
  onDismiss: () => void
  textScale: 'normal' | 'large' | 'extra'
}

const textSizeMap = {
  normal: 'text-sm',
  large: 'text-base',
  extra: 'text-lg',
}

export function SafetyBanner({ isVisible, onDismiss, textScale }: SafetyBannerProps) {
  if (!isVisible) return null

  return (
    <div className="bg-amber-600 border-b-4 border-amber-700 px-4 py-4 flex items-start justify-between gap-3">
      <div className="flex items-start gap-3 flex-1">
        <AlertTriangle 
          size={28}
          className="text-white flex-shrink-0 mt-1"
          aria-label="Warning"
        />
        <div>
          <div className={`${textSizeMap[textScale]} font-bold text-white mb-1`}>
            ⚠️ THIS IS NOT A SUBSTITUTE FOR EMERGENCY SERVICES
          </div>
          <p className={`${textSizeMap[textScale]} text-white/90 leading-relaxed`}>
            If experiencing severe symptoms, chest pain, difficulty breathing, or loss of consciousness: CALL 911 IMMEDIATELY or go to the nearest emergency room.
          </p>
        </div>
      </div>
      
      <button
        onClick={onDismiss}
        className="flex-shrink-0 p-2 hover:bg-amber-700 rounded-lg transition-colors"
        aria-label="Dismiss safety banner"
      >
        <X size={20} className="text-white" />
      </button>
    </div>
  )
}
