'use client'

import { WifiOff } from 'lucide-react'

interface StatusBarProps {
  isOffline: boolean
}

export function StatusBar({ isOffline }: StatusBarProps) {
  const sizeClass = {
    normal: 'text-sm',
    large: 'text-base',
    extra: 'text-lg',
  }

  return (
    <div className="bg-slate-900 border-b-4 border-slate-700 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-2">
        {isOffline && (
          <>
            <WifiOff 
              size={24} 
              className="text-amber-400"
              aria-label="Offline mode"
            />
            <span className="text-amber-400 font-bold text-base">
              OFFLINE MODE
            </span>
          </>
        )}
        {!isOffline && (
          <span className="text-emerald-400 font-bold text-base">
            ✓ READY
          </span>
        )}
      </div>
      
      <div className="text-gray-300 text-xs font-mono">
        {new Date().toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: true 
        })}
      </div>
    </div>
  )
}
