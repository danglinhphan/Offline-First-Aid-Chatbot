'use client'

interface VisualGuideProps {
  textScale: 'normal' | 'large' | 'extra'
}

const textSizeMap = {
  normal: 'text-base',
  large: 'text-lg',
  extra: 'text-xl',
}

export function VisualGuide({ textScale }: VisualGuideProps) {
  return (
    <div className="bg-slate-800 border-b-2 border-slate-700 px-4 py-4">
      <div className={`${textSizeMap[textScale]} font-bold text-white mb-3`}>
        Quick Steps
      </div>
      
      <div className="space-y-2">
        <div className="flex gap-3 items-start">
          <div className="bg-emerald-500 text-slate-900 font-bold w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm">
            1
          </div>
          <div className={`${textSizeMap[textScale]} text-white leading-relaxed`}>
            Describe your symptoms clearly
          </div>
        </div>
        
        <div className="flex gap-3 items-start">
          <div className="bg-emerald-500 text-slate-900 font-bold w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm">
            2
          </div>
          <div className={`${textSizeMap[textScale]} text-white leading-relaxed`}>
            Listen to immediate guidance
          </div>
        </div>
        
        <div className="flex gap-3 items-start">
          <div className="bg-emerald-500 text-slate-900 font-bold w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm">
            3
          </div>
          <div className={`${textSizeMap[textScale]} text-white leading-relaxed`}>
            Follow next steps carefully
          </div>
        </div>
      </div>
    </div>
  )
}
