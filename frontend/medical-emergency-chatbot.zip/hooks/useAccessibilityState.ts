'use client'

import { useState, useCallback } from 'react'

export type TextScale = 'normal' | 'large' | 'extra'

export interface AccessibilityState {
  isListening: boolean
  textScale: TextScale
  isPlayingVoice: boolean
  isSlowSpeed: boolean
  isHighContrast: boolean
  disclaimerVisible: boolean
}

export function useAccessibilityState() {
  const [state, setState] = useState<AccessibilityState>({
    isListening: false,
    textScale: 'normal',
    isPlayingVoice: false,
    isSlowSpeed: false,
    isHighContrast: true,
    disclaimerVisible: true,
  })

  const setIsListening = useCallback((value: boolean) => {
    setState(prev => ({ ...prev, isListening: value }))
  }, [])

  const setTextScale = useCallback((value: TextScale) => {
    setState(prev => ({ ...prev, textScale: value }))
  }, [])

  const setIsPlayingVoice = useCallback((value: boolean) => {
    setState(prev => ({ ...prev, isPlayingVoice: value }))
  }, [])

  const setIsSlowSpeed = useCallback((value: boolean) => {
    setState(prev => ({ ...prev, isSlowSpeed: value }))
  }, [])

  const setIsHighContrast = useCallback((value: boolean) => {
    setState(prev => ({ ...prev, isHighContrast: value }))
  }, [])

  const setDisclaimerVisible = useCallback((value: boolean) => {
    setState(prev => ({ ...prev, disclaimerVisible: value }))
  }, [])

  return {
    ...state,
    setIsListening,
    setTextScale,
    setIsPlayingVoice,
    setIsSlowSpeed,
    setIsHighContrast,
    setDisclaimerVisible,
  }
}
